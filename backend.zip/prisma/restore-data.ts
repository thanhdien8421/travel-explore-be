import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Script để restore parsed places vào database mới
 * Usage: npx tsx prisma/restore-data.ts
 */

const prisma = new PrismaClient();

interface ParsedPlace {
  id: string;
  name: string;
  slug: string;
  description?: string;
  streetAddress?: string;
  ward: string;
  district?: string;
  provinceCity: string;
  locationDescription?: string;
  fullAddressGenerated: string;
  latitude?: string;
  longitude?: string;
  coverImageUrl?: string;
  openingHours?: string;
  priceInfo?: string;
  contactInfo?: string;
  tipsNotes?: string;
  isFeatured: boolean;
  isActive: boolean;
  averageRating: string;
  createdAt: string;
  updatedAt: string;
}

async function main() {
  try {
    // Đọc backup data
    const backupDir = path.join(process.cwd(), 'backups');
    const backupPath = path.join(backupDir, 'backup-2025-11-19T18-28-51-661Z.json');

    if (!fs.existsSync(backupPath)) {
      console.log('❌ File backup không tìm thấy');
      return;
    }

    console.log('📂 Đọc backup data...');
    const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));

    // Restore users first
    if (backupData.users && backupData.users.length > 0) {
      console.log(`\n👥 Restoring ${backupData.users.length} users...`);
      for (const user of backupData.users) {
        try {
          await prisma.user.create({
            data: {
              id: user.id,
              fullName: user.fullName || null,
              email: user.email,
              passwordHash: user.passwordHash,
              role: user.role || 'USER',
              createdAt: new Date(user.createdAt),
            },
          });
          console.log(`✅ Created user: ${user.email}`);
        } catch (error) {
          console.error(`❌ Error creating user ${user.email}:`, (error as any).message);
        }
      }
    }

    // Restore places
    if (backupData.places && backupData.places.length > 0) {
      console.log(`\n📍 Restoring ${backupData.places.length} places...`);
      for (const place of backupData.places) {
        try {
          await prisma.place.create({
            data: {
              id: place.id,
              name: place.name,
              slug: place.slug,
              description: place.description || null,
              streetAddress: place.streetAddress || null,
              ward: place.ward,
              district: place.district || null,
              provinceCity: place.provinceCity,
              locationDescription: place.locationDescription || null,
              fullAddressGenerated: place.fullAddressGenerated,
              latitude: place.latitude ? parseFloat(place.latitude) : null,
              longitude: place.longitude ? parseFloat(place.longitude) : null,
              coverImageUrl: place.coverImageUrl || null,
              openingHours: place.openingHours || null,
              priceInfo: place.priceInfo || null,
              contactInfo: place.contactInfo || null,
              tipsNotes: place.tipsNotes || null,
              isFeatured: place.isFeatured,
              isActive: place.isActive,
              averageRating: place.averageRating ? parseFloat(place.averageRating) : 0,
              createdAt: new Date(place.createdAt),
              updatedAt: new Date(place.updatedAt),
            },
          });
          console.log(`✅ Created place: ${place.name}`);
        } catch (error) {
          console.error(`❌ Error creating place ${place.name}:`, (error as any).message);
        }
      }
    }

    // Restore reviews
    if (backupData.reviews && backupData.reviews.length > 0) {
      console.log(`\n⭐ Restoring ${backupData.reviews.length} reviews...`);
      for (const review of backupData.reviews) {
        try {
          await prisma.review.create({
            data: {
              id: review.id,
              placeId: review.placeId,
              userId: review.userId,
              rating: review.rating,
              comment: review.comment || null,
              createdAt: new Date(review.createdAt),
            },
          });
          console.log(`✅ Created review for place ${review.placeId}`);
        } catch (error) {
          console.error(`❌ Error creating review:`, (error as any).message);
        }
      }
    }

    // Restore user visits
    if (backupData.userVisits && backupData.userVisits.length > 0) {
      console.log(`\n📌 Restoring ${backupData.userVisits.length} user visits...`);
      for (const visit of backupData.userVisits) {
        try {
          await prisma.userVisit.create({
            data: {
              id: visit.id,
              userId: visit.userId,
              placeId: visit.placeId,
              visitedAt: new Date(visit.visitedAt),
            },
          });
          console.log(`✅ Created user visit`);
        } catch (error) {
          console.error(`❌ Error creating user visit:`, (error as any).message);
        }
      }
    }

    console.log(`\n✅ Restore data thành công!`);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
