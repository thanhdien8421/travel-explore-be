import { PrismaClient } from '@prisma/client';

/**
 * Script để transform places data sau khi migration
 * Tạo fullAddressGenerated và fix ward từ default
 * 
 * Usage: npx tsx prisma/transform-data.ts
 */

const prisma = new PrismaClient();

function generateFullAddress(
  streetAddress?: string | null,
  ward?: string,
  district?: string | null,
  provinceCity?: string
): string {
  const parts = [];
  if (streetAddress) parts.push(streetAddress);
  if (ward && ward !== 'Phường/Xã') parts.push(ward);
  if (district && district !== 'Quận 3') parts.push(district);
  if (provinceCity) parts.push(provinceCity);
  return parts.filter(Boolean).join(', ');
}

async function main() {
  try {
    console.log('🔄 Transform places data...\n');

    const places = await prisma.place.findMany();

    let updateCount = 0;

    for (const place of places) {
      // Nếu ward còn là default, tìm ward thích hợp dựa trên district
      let ward = place.ward;
      if (place.ward === 'Phường/Xã' && place.district) {
        // Default ward based on district
        if (place.district.includes('Quận 1')) {
          ward = 'Phường Bến Thành';
        } else if (place.district.includes('Quận 3')) {
          ward = 'Phường 6';
        } else if (place.district.includes('Bình Thạnh')) {
          ward = 'Phường 1';
        } else {
          ward = 'Phường Thủ Đức';
        }
      }

      const fullAddress = generateFullAddress(
        place.streetAddress,
        ward,
        place.district,
        place.provinceCity
      );

      if (fullAddress !== place.fullAddressGenerated || ward !== place.ward) {
        await prisma.place.update({
          where: { id: place.id },
          data: {
            ward,
            fullAddressGenerated: fullAddress,
          },
        });
        console.log(`✅ ${place.name}`);
        updateCount++;
      }
    }

    console.log(`\n📊 Total updated: ${updateCount} / ${places.length}`);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
