import { PrismaClient } from '@prisma/client';

/**
 * Script để seed initial categories vào database
 * 
 * Usage: npx ts-node prisma/seed-categories.ts
 */

const prisma = new PrismaClient();

const INITIAL_CATEGORIES = [
  // Ẩm thực & Đồ uống
  { name: 'Nhà hàng', slug: 'nha-hang' },
  { name: 'Quán ăn', slug: 'quan-an' },
  { name: 'Quán cà phê', slug: 'quan-ca-phe' },
  { name: 'Bar/Pub', slug: 'bar-pub' },
  { name: 'Ăn vặt/Đường phố', slug: 'an-vat-duong-pho' },

  // Tham quan & Văn hóa
  { name: 'Điểm tham quan', slug: 'diem-tham-quan' },
  { name: 'Di tích lịch sử', slug: 'di-tich-lich-su' },
  { name: 'Bảo tàng & Triển lãm', slug: 'bao-tang-trien-lam' },
  { name: 'Tôn giáo & Tín ngưỡng', slug: 'ton-giao-tin-nguong' },

  // Mua sắm & Giải trí
  { name: 'Mua sắm', slug: 'mua-sam' },
  { name: 'Chợ địa phương', slug: 'cho-dia-phuong' },
  { name: 'Không gian sáng tạo', slug: 'khong-gian-sang-tao' },

  // Giải trí & Thư giãn
  { name: 'Công viên & Không gian xanh', slug: 'cong-vien-khong-gian-xanh' },
  { name: 'Trải nghiệm & Workshop', slug: 'trai-nghiem-workshop' }
];

async function main() {
  try {
    console.log('🌱 Bắt đầu seed categories...\n');

    for (const cat of INITIAL_CATEGORIES) {
      const existing = await prisma.category.findUnique({
        where: { slug: cat.slug }
      });

      if (existing) {
        console.log(`⏭️  Skip: ${cat.name} (đã tồn tại)`);
      } else {
        await prisma.category.create({
          data: cat
        });
        console.log(`✅ Created: ${cat.name}`);
      }
    }

    console.log('\n✅ Seed categories thành công!');
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
