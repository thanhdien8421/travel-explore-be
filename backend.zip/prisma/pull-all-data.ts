import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Script để pull toàn bộ data từ database
 * Usage: npx tsx prisma/pull-all-data.ts
 */

const prisma = new PrismaClient();

async function main() {
  try {
    console.log('📂 Pulling data từ database...\n');

    // Pull places
    const places = await prisma.place.findMany({
      include: {
        images: true,
        reviews: true,
        userVisits: true,
        categories: {
          include: {
            category: true,
          },
        },
      },
    });

    // Pull users
    const users = await prisma.user.findMany({
      include: {
        reviews: true,
        userVisits: true,
      },
    });

    // Pull categories
    const categories = await prisma.category.findMany();

    const backup = {
      places: places.map(p => ({
        ...p,
        latitude: p.latitude?.toNumber(),
        longitude: p.longitude?.toNumber(),
        averageRating: p.averageRating?.toNumber(),
      })),
      users,
      categories,
      placeImages: places.flatMap(p => p.images),
      reviews: places.flatMap(p => p.reviews),
      userVisits: places.flatMap(p => p.userVisits),
    };

    // Lưu backup
    const backupDir = path.join(process.cwd(), 'backups');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(backupDir, `backup-${timestamp}.json`);

    fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2));

    console.log(`✅ Pulled ${places.length} places`);
    console.log(`✅ Pulled ${users.length} users`);
    console.log(`✅ Pulled ${categories.length} categories`);
    console.log(`\n📄 Backup lưu vào: ${backupPath}`);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
