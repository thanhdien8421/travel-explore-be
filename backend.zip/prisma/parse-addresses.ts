import * as fs from 'fs';
import * as path from 'path';

/**
 * Script để parse địa chỉ cũ thành cấu trúc mới
 * addressText: "135 Nam Kỳ Khởi Nghĩa, Phường Bến Thành, Quận 1, TP. Hồ Chí Minh"
 * →
 * streetAddress: "135 Nam Kỳ Khởi Nghĩa"
 * ward: "Phường Bến Thành"
 * district: "Quận 1"
 * provinceCity: "TP. Hồ Chí Minh"
 */

interface OldPlace {
  id: string;
  name: string;
  slug: string;
  description?: string;
  addressText?: string;
  district?: string;
  city?: string;
  latitude?: string;
  longitude?: string;
  coverImageUrl?: string;
  openingHours?: string;
  priceInfo?: string;
  contactInfo?: string;
  tipsNotes?: string;
  isFeatured: boolean;
  isActive: boolean;
  averageRating: string;
  createdAt: string;
  updatedAt: string;
}

interface ParsedPlace {
  id: string;
  name: string;
  slug: string;
  description?: string;
  streetAddress?: string;
  ward: string;
  district?: string;
  provinceCity: string;
  locationDescription?: string;
  fullAddressGenerated?: string;
  latitude?: string;
  longitude?: string;
  coverImageUrl?: string;
  openingHours?: string;
  priceInfo?: string;
  contactInfo?: string;
  tipsNotes?: string;
  isFeatured: boolean;
  isActive: boolean;
  averageRating: string;
  createdAt: string;
  updatedAt: string;
}

function parseAddress(addressText?: string, existingDistrict?: string): {
  streetAddress?: string;
  ward: string;
  district?: string;
  provinceCity: string;
  fullAddressGenerated: string;
} {
  const defaultWard = 'Phường Thủ Đức';
  const defaultCity = 'TP. Hồ Chí Minh';

  // Nếu không có addressText, trả về default
  if (!addressText || addressText.trim() === '') {
    return {
      ward: defaultWard,
      provinceCity: defaultCity,
      fullAddressGenerated: defaultCity
    };
  }

  // Parse addressText: "135 Nam Kỳ Khởi Nghĩa, Phường Bến Thành, Quận 1, TP. Hồ Chí Minh"
  const parts = addressText.split(',').map(p => p.trim());

  if (parts.length === 0) {
    return {
      ward: defaultWard,
      provinceCity: defaultCity,
      fullAddressGenerated: addressText
    };
  }

  let streetAddress: string | undefined;
  let ward: string = defaultWard;
  let district: string | undefined;
  let provinceCity: string = defaultCity;

  // Lần lượt parse từng phần
  parts.forEach((part, index) => {
    if (part.includes('Phường') || part.includes('Xã')) {
      ward = part;
    } else if (part.includes('Quận') || part.includes('Huyện') || part.includes('TP.')) {
      // Có thể là district hoặc city
      if (part.includes('TP.')) {
        provinceCity = part;
      } else {
        district = part;
      }
    } else if (index === 0) {
      // Phần đầu tiên thường là số nhà và tên đường
      streetAddress = part;
    }
  });

  // Ghép full_address_generated từ các phần
  const addressParts = [streetAddress, ward, district, provinceCity].filter(Boolean);
  const fullAddressGenerated = addressParts.join(', ');

  return {
    streetAddress,
    ward,
    district,
    provinceCity,
    fullAddressGenerated
  };
}

function transformPlace(oldPlace: OldPlace): ParsedPlace {
  const parsed = parseAddress(oldPlace.addressText, oldPlace.district);

  return {
    id: oldPlace.id,
    name: oldPlace.name,
    slug: oldPlace.slug,
    description: oldPlace.description,
    streetAddress: parsed.streetAddress,
    ward: parsed.ward,
    district: parsed.district,
    provinceCity: parsed.provinceCity,
    locationDescription: undefined, // Tạm không có data cũ cho cái này
    fullAddressGenerated: parsed.fullAddressGenerated,
    latitude: oldPlace.latitude,
    longitude: oldPlace.longitude,
    coverImageUrl: oldPlace.coverImageUrl,
    openingHours: oldPlace.openingHours,
    priceInfo: oldPlace.priceInfo,
    contactInfo: oldPlace.contactInfo,
    tipsNotes: oldPlace.tipsNotes,
    isFeatured: oldPlace.isFeatured,
    isActive: oldPlace.isActive,
    averageRating: oldPlace.averageRating,
    createdAt: oldPlace.createdAt,
    updatedAt: oldPlace.updatedAt
  };
}

async function main() {
  try {
    // Đọc backup file
    const backupDir = path.join(process.cwd(), 'backups');
    const files = fs.readdirSync(backupDir).filter(f => f.startsWith('pre-migration-backup-'));

    if (files.length === 0) {
      console.log('❌ Không tìm thấy backup file');
      return;
    }

    const latestFile = files.sort().reverse()[0];
    const backupPath = path.join(backupDir, latestFile);

    console.log(`📂 Đọc backup file: ${latestFile}`);
    const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));

    // Transform places
    const transformedPlaces = backupData.places.map((place: OldPlace) => transformPlace(place));

    // Lưu transformed data
    const outputPath = path.join(backupDir, 'parsed-places.json');
    fs.writeFileSync(outputPath, JSON.stringify(transformedPlaces, null, 2));

    console.log(`✅ Đã parse ${transformedPlaces.length} places`);
    console.log(`📄 Lưu vào: ${outputPath}`);

    // Show sample
    console.log('\n📋 Sample (place đầu tiên):');
    console.log(JSON.stringify(transformedPlaces[0], null, 2));
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

main();
