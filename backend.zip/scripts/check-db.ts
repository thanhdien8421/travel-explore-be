import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const count = await prisma.place.count();
  const sample = await prisma.place.findFirst({
    select: {
      id: true,
      name: true,
      ward: true,
      fullAddressGenerated: true,
      streetAddress: true,
      district: true,
    },
  });

  console.log('Total places in DB:', count);
  console.log('\nSample place:');
  console.log(JSON.stringify(sample, null, 2));

  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
