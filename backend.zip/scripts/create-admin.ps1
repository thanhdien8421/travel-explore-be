# Quick Admin User Creation Script (PowerShell)
# Usage: .\create-admin.ps1 [email] [password] [fullname]
# Example: .\create-admin.ps1 -Email "admin@app.local" -Password "SecurePass123" -FullName "John Admin"

param(
    [string]$Email = "admin@travelexplore.local",
    [string]$Password = "Admin@123456",
    [string]$FullName = "Admin User"
)

# Colors
$Green = @{ ForegroundColor = 'Green' }
$Blue = @{ ForegroundColor = 'Blue' }
$Yellow = @{ ForegroundColor = 'Yellow' }
$Red = @{ ForegroundColor = 'Red' }

# Check if in correct directory
if (-not (Test-Path "prisma/schema.prisma")) {
    Write-Host "❌ Error: Must run from project root directory" @Red
    exit 1
}

Write-Host "🔐 Creating Admin User`n" @Blue
Write-Host "Email: $Email" -NoNewline
Write-Host " (changeable later)" @Yellow
Write-Host "Full Name: $FullName" @Yellow
Write-Host ""

# Create TypeScript script content
$TempScript = @"
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const SALT_ROUNDS = 10;

const email = `$Email`;
const password = `$Password`;
const fullName = `$FullName`;

async function createAdmin() {
  try {
    const existing = await prisma.user.findUnique({ where: { email } });
    
    if (existing) {
      console.log(`⚠️  User ${existing.email} already exists (ID: ${existing.id})`);
      await prisma.`$disconnect();
      return;
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        fullName,
        role: 'ADMIN',
      },
      select: { id: true, email: true, fullName: true, role: true, createdAt: true },
    });

    console.log(`✅ Admin created!\nEmail: ${user.email}\nID: ${user.id}`);
  } catch (error) {
    console.error('❌ Error:', error instanceof Error ? error.message : error);
    process.exit(1);
  } finally {
    await prisma.`$disconnect();
  }
}

createAdmin();
"@

# Create temp file
$TempFile = New-TemporaryFile -ErrorAction Stop
$TempFile = Rename-Item -Path $TempFile -NewName "$($TempFile.BaseName).ts" -PassThru

# Write script
$TempScript | Set-Content -Path $TempFile -ErrorAction Stop

try {
    # Execute
    Write-Host "⏳ Creating admin..." @Yellow
    npx tsx $TempFile.FullName
} finally {
    # Cleanup
    Remove-Item -Path $TempFile -Force -ErrorAction Continue
}

Write-Host "`n✅ Done!`n" @Green
