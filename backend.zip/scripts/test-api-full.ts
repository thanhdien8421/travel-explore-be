/**
 * API Test Script - Test all endpoints
 */

const BASE_API_URL = 'http://localhost:8000';

interface APITestResult {
  testName: string;
  status: 'PASS' | 'FAIL';
  errorMsg?: string;
}

const testResults: APITestResult[] = [];

async function runAPITest(testName: string, fn: () => Promise<void>) {
  try {
    await fn();
    testResults.push({ testName, status: 'PASS' });
    console.log(`✅ ${testName}`);
  } catch (error: any) {
    testResults.push({ testName, status: 'FAIL', errorMsg: error.message });
    console.log(`❌ ${testName}: ${error.message}`);
  }
}

async function fetchApi(endpoint: string, options: any = {}) {
  const res = await fetch(`${BASE_API_URL}${endpoint}`, options);
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: ${res.statusText}`);
  }
  return res.json();
}

async function main() {
  console.log('🧪 Testing Travel Explore API\n');

  // Test 1: Health check
  await runAPITest('GET /health - Health check', async () => {
    const data = await fetchApi('/health');
    if (!data.status || (data.status !== 'ok' && data.status !== 'success')) throw new Error('Health check failed');
  });

  let testPlaceId = '';
  let jwtToken = '';
  let userId = '';

  // Test 1.5: Login to get JWT token
  await runAPITest('POST /api/auth/login - Login', async () => {
    const response = await fetch(`${BASE_API_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'user@example.com',
        password: 'password123'
      })
    });
    if (!response.ok) throw new Error(`Login failed with status ${response.status}`);
    const data = await response.json();
    if (!data.token) throw new Error('No token in response');
    jwtToken = data.token;
    userId = data.user?.id;
    console.log(`     → Token received, User ID: ${userId}`);
  });

  // Test 2: Get all places
  await runAPITest('GET /api/places - All places', async () => {
    const data = await fetchApi('/api/places');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    if (data.data.length === 0) throw new Error('No places found');
    testPlaceId = data.data[0].id;
    if (!data.data[0].latitude || !data.data[0].longitude) throw new Error('Missing coordinates');
    console.log(`     → Found ${data.data.length} places with coordinates`);
  });

  // Test 3: Search places
  await runAPITest('GET /api/places?q=coffee - Search', async () => {
    const data = await fetchApi('/api/places?q=coffee');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    if (data.data.length > 0 && (!data.data[0].latitude || !data.data[0].longitude)) {
      throw new Error('Missing coordinates in search results');
    }
    console.log(`     → Found ${data.data.length} results for "coffee" with coordinates`);
  });

  // Test 4: Filter by ward
  await runAPITest('GET /api/places?ward=Phường Bến Thành - Filter by ward', async () => {
    const data = await fetchApi('/api/places?ward=Ph%C6%B0%E1%BB%9Dng%20B%E1%BA%BFn%20Th%C3%A0nh');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    console.log(`     → Found ${data.data.length} places in ward`);
  });

  // Test 4.5: Filter by category
  await runAPITest('GET /api/places?category=di-tich-lich-su - Filter by category', async () => {
    const data = await fetchApi('/api/places?category=di-tich-lich-su');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    console.log(`     → Found ${data.data.length} places in category`);
  });

  // Test 5: Pagination
  await runAPITest('GET /api/places?limit=5&page=1 - Pagination', async () => {
    const data = await fetchApi('/api/places?limit=5&page=1');
    if (!data.pagination) throw new Error('No pagination info');
    console.log(`     → Total: ${data.pagination.totalItems}, Page: ${data.pagination.currentPage}`);
  });

  // Test 6: Sort by name
  await runAPITest('GET /api/places?sortBy=name_asc - Sort', async () => {
    const data = await fetchApi('/api/places?sortBy=name_asc&limit=5');
    if (!data.data || data.data.length === 0) throw new Error('No data');
    if (!data.data[0].latitude || !data.data[0].longitude) throw new Error('Missing coordinates');
    console.log(`     → First: ${data.data[0].name} (lat: ${data.data[0].latitude}, lon: ${data.data[0].longitude})`);
  });

  // Test 7: Featured places
  await runAPITest('GET /api/places?featured=true - Featured', async () => {
    const data = await fetchApi('/api/places?featured=true');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    if (data.data.length > 0 && (!data.data[0].latitude || !data.data[0].longitude)) {
      throw new Error('Missing coordinates in featured places');
    }
    console.log(`     → Found ${data.data.length} featured places with coordinates`);
  });

  // Test 8: Get single place by slug
  if (testPlaceId) {
    let placeSlug = '';
    await runAPITest('GET /api/places - Get first place for slug', async () => {
      const data = await fetchApi('/api/places?limit=1');
      if (!data.data || data.data.length === 0) throw new Error('No places found');
      placeSlug = data.data[0].slug;
      console.log(`     → Slug: ${placeSlug}`);
    });

    // Test 9: Get by slug
    if (placeSlug) {
      await runAPITest(`GET /api/places/{slug} - Get by slug`, async () => {
        const data = await fetchApi(`/api/places/${placeSlug}`);
        // Response can be either wrapped in {data: {...}} or direct object
        const place = data.data || data;
        if (!place || !place.name) throw new Error('Invalid place data');
        console.log(`     → Place: ${place.name}`);
      });
    }
  }

  // Test 10: Create review
  if (testPlaceId && jwtToken) {
    await runAPITest('POST /api/places/{placeId}/reviews - Create review', async () => {
      const response = await fetch(`${BASE_API_URL}/api/places/${testPlaceId}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${jwtToken}`
        },
        body: JSON.stringify({
          rating: 5,
          comment: 'Tuyệt vời! Nơi này quá đáng để ghé thăm'
        })
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      const data = await response.json();
      // Response can be either wrapped in {data: {...}} or direct object
      const review = data.data || data;
      if (!review || !review.rating) throw new Error('Invalid review response');
      console.log(`     → Review created with rating: ${review.rating}`);
    });
  }

  // Test 11: Get all categories
  await runAPITest('GET /api/categories - Get all categories', async () => {
    const data = await fetchApi('/api/categories');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    if (data.data.length === 0) throw new Error('No categories found');
    if (!data.data[0].id || !data.data[0].name || !data.data[0].slug) {
      throw new Error('Missing required category fields');
    }
    console.log(`     → Found ${data.data.length} categories`);
  });

  // Test 12: Get all wards
  await runAPITest('GET /api/wards - Get all wards', async () => {
    const data = await fetchApi('/api/wards');
    if (!data.data || !Array.isArray(data.data)) throw new Error('Invalid response');
    if (data.data.length === 0) throw new Error('No wards found');
    console.log(`     → Found ${data.data.length} unique wards`);
  });

  // Test 13: API Documentation
  await runAPITest('GET /api-docs - Swagger docs', async () => {
    const res = await fetch(`${BASE_API_URL}/api-docs`);
    if (!res.ok) throw new Error('Swagger docs not available');
  });

  // Summary
  console.log('\n📊 Test Summary:');
  const passed = testResults.filter(r => r.status === 'PASS').length;
  const failed = testResults.filter(r => r.status === 'FAIL').length;
  console.log(`✅ Passed: ${passed}/${testResults.length}`);
  if (failed > 0) {
    console.log(`❌ Failed: ${failed}`);
    console.log('\n❌ Failed tests:');
    testResults.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`   • ${r.testName}: ${r.errorMsg}`);
    });
  } else {
    console.log('🎉 All tests passed!');
  }

  process.exit(failed > 0 ? 1 : 0);
}

main().catch(console.error);
