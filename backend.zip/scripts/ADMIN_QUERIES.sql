-- Admin User Management SQL Queries
-- These queries can be run directly against PostgreSQL/Supabase

-- ============================================
-- 1. VIEW ALL ADMIN USERS
-- ============================================
SELECT 
  id,
  email,
  full_name,
  role,
  created_at
FROM users 
WHERE role = 'ADMIN'
ORDER BY created_at DESC;

-- ============================================
-- 2. VIEW ALL USERS (Admin + Regular)
-- ============================================
SELECT 
  id,
  email,
  full_name,
  role,
  created_at
FROM users
ORDER BY role DESC, created_at DESC;

-- ============================================
-- 3. CHECK SPECIFIC USER
-- ============================================
SELECT * FROM users WHERE email = 'admin@travelexplore.local';

-- ============================================
-- 4. COUNT USERS BY ROLE
-- ============================================
SELECT 
  role,
  COUNT(*) as count
FROM users
GROUP BY role;

-- ============================================
-- 5. PROMOTE USER TO ADMIN
-- ============================================
-- CAUTION: This directly modifies the role without validation
-- Better to use the TypeScript script instead
UPDATE users 
SET role = 'ADMIN' 
WHERE email = 'user@example.com'
  AND role = 'USER';

-- ============================================
-- 6. DEMOTE ADMIN TO USER
-- ============================================
UPDATE users 
SET role = 'USER' 
WHERE email = 'admin@travelexplore.local'
  AND role = 'ADMIN';

-- ============================================
-- 7. DISABLE/DELETE ADMIN (Soft Delete)
-- ============================================
-- Recommended: Use soft delete pattern
-- Add `is_active BOOLEAN DEFAULT true` to users table first
-- Then: UPDATE users SET is_active = FALSE WHERE id = '...';

-- ============================================
-- 8. HARD DELETE USER (USE WITH CAUTION!)
-- ============================================
-- This deletes user and all their reviews/visits
DELETE FROM reviews WHERE user_id = '...';
DELETE FROM user_visits WHERE user_id = '...';
DELETE FROM users WHERE id = '...';

-- ============================================
-- 9. RESET PASSWORD TO DEFAULT (via UPDATE)
-- ============================================
-- Note: Password hashes cannot be reversed
-- Must use bcrypt hash directly (not recommended)
-- Better to implement "Forgot Password" flow

-- To generate a bcrypt hash of "TempPassword123" with salt=10:
-- You must use: bcrypt.hash("TempPassword123", 10) in your app code first
-- Then update: UPDATE users SET password_hash = '$2b$10$...' WHERE id = '...';

-- ============================================
-- 10. VIEW USER STATS
-- ============================================
SELECT 
  u.id,
  u.email,
  u.full_name,
  u.role,
  COUNT(r.id) as review_count,
  COUNT(uv.id) as visit_count,
  u.created_at
FROM users u
LEFT JOIN reviews r ON u.id = r.user_id
LEFT JOIN user_visits uv ON u.id = uv.user_id
GROUP BY u.id
ORDER BY u.created_at DESC;

-- ============================================
-- IMPORTANT NOTES
-- ============================================
-- 1. Password hashes are bcrypt-encoded
--    - Cannot be reversed or decrypted
--    - Must use bcrypt.compare() to verify
--    - Never view/share password hash
--
-- 2. Role values:
--    - 'ADMIN' = Admin access to /api/admin/* endpoints
--    - 'USER' = Regular user (can review/visit places)
--
-- 3. For password reset:
--    - Implement "Forgot Password" email flow
--    - Generate secure token
--    - User sets new password via secure link
--    - Hash new password with bcrypt before storing
--
-- 4. For user management:
--    - Always use TypeScript scripts for consistency
--    - Direct SQL should only be for emergencies
--    - Keep audit log of admin changes
