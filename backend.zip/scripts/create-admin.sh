#!/bin/bash

# Quick Admin User Creation Script
# Usage: ./create-admin.sh [email] [password] [fullname]
# Example: ./create-admin.sh admin@app.local "SecurePass123" "John Admin"

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if running from correct directory
if [ ! -f "prisma/schema.prisma" ]; then
    echo -e "${RED}❌ Error: Must run from project root directory${NC}"
    exit 1
fi

# Get parameters
EMAIL="${1:-admin@travelexplore.local}"
PASSWORD="${2:-Admin@123456}"
FULLNAME="${3:-Admin User}"

echo -e "${BLUE}🔐 Creating Admin User${NC}\n"
echo -e "Email: ${YELLOW}$EMAIL${NC}"
echo -e "Full Name: ${YELLOW}$FULLNAME${NC}\n"

# Create a temporary TypeScript script
TEMP_SCRIPT=$(mktemp --suffix=.ts)

cat > "$TEMP_SCRIPT" << 'EOF'
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const SALT_ROUNDS = 10;

const email = process.argv[2] || 'admin@travelexplore.local';
const password = process.argv[3] || 'Admin@123456';
const fullName = process.argv[4] || 'Admin User';

async function createAdmin() {
  try {
    const existing = await prisma.user.findUnique({ where: { email } });
    
    if (existing) {
      console.log(`⚠️  User ${email} already exists (ID: ${existing.id})`);
      await prisma.$disconnect();
      return;
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        fullName,
        role: 'ADMIN',
      },
      select: { id: true, email: true, fullName: true, role: true, createdAt: true },
    });

    console.log(`✅ Admin created!\nEmail: ${user.email}\nID: ${user.id}`);
  } catch (error) {
    console.error('❌ Error:', error instanceof Error ? error.message : error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

createAdmin();
EOF

# Run the script
npx tsx "$TEMP_SCRIPT" "$EMAIL" "$PASSWORD" "$FULLNAME"

# Cleanup
rm "$TEMP_SCRIPT"

echo -e "\n${GREEN}✅ Done!${NC}\n"
