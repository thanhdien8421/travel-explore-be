import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function verify() {
  const places = await prisma.place.count();
  const categories = await prisma.category.count();
  const placeCategories = await prisma.placeCategory.count();
  const cats = await prisma.category.findMany({ select: { name: true } });
  
  console.log('✅ Database Verification:');
  console.log(`   Places: ${places}`);
  console.log(`   Categories: ${categories}`);
  console.log(`   Place-Category Mappings: ${placeCategories}`);
  console.log(`   Category List: ${cats.map(c => c.name).join(', ')}`);
  
  await prisma.$disconnect();
}

verify();
